/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLogic;

import Data.Ficha;
import Data.Reina;
import Data.Rey;
import Data.Tablero;
import UI.AjedrezUI;
import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class Ajedrez {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s = new Scanner(System.in);
        Ficha rey1 = new Rey(3, 1, 'W');
        Ficha reina1 = new Reina(4, 1, 'W');
        Ficha rey2 = new Rey(3, 8, 'B');
        Ficha reina2 = new Reina(4, 8, 'B');

        Ficha[] Blancas = {rey1, reina1};
        Ficha[] Negras = {rey2, reina2};
        Tablero tablero = new Tablero(Blancas, Negras);
        while (2 > 0) {
            int turno = 1;
            System.out.println("Turno " + turno++);
            AjedrezUI.printTablero(tablero.getTablero());
            int n = s.nextInt();
            Blancas[n].moverFicha(AjedrezUI.traducirPosicionX(s.next().charAt(0)), AjedrezUI.traducirPosicionY(s.nextInt()));
            Blancas[n].comerFicha(rey1);
            tablero.setTablero(Blancas, Negras);
            AjedrezUI.printTablero(tablero.getTablero());
            n=s.nextInt();
            Negras[n].moverFicha(AjedrezUI.traducirPosicionX(s.next().charAt(0)), AjedrezUI.traducirPosicionY(s.nextInt()));
            Negras[n].comerFicha(rey2);
            tablero.setTablero(Blancas, Negras);

        }
    }

}
