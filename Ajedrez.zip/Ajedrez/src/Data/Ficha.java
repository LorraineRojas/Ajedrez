/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author nico_
 */
public abstract class Ficha {

    private char ficha;
    /* este caracter va a ser el que se imprima
    en la matriz:
    ficha = k; para el rey negro
    ficha = q; para la reina negra
    ficha = b; para el alfil negro
    ficha = h; para el caballo negro
    ficha = r; para la torre negra
    ficha = p; para el peon negro
    el paso a mayusculas para blancas la realiza el constructor
     */
    private int x, y;
    /*coordenadas en X y en Y de la ficha en el tablero
    IMPORTANTE: las coordenadas aunque sean en una matriz empezaran desde 1
    y no desde 0
     */
    private char color;

    // B o W
    public Ficha(char ficha, int x, int y, char color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.ficha = ficha;
        if (this.color == 'W') {
            this.ficha = Character.toUpperCase(ficha);

        }

    }

    protected void setFicha(char Ficha) {
        this.ficha = ficha;
    }

    protected void setPosicion(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public char getFicha() {
        return ficha;
    }

    public abstract void moverFicha(int x, int y);

    /*comprueba la posicion de la ficha con respecto al tablero
    y luego analiza los nuevos parametros para comprobar si el movimiento es posible.
    si el movimiento es posible this.x = x y this.y = y si no lo es imprima error de 
    posicion y vuelva a realizar la funcion. ademas, para el peon si hay una ficha en las 
    dos diagonales de frente puede tambien mover en diagonal
     */
    public void fichaComida() {

        this.x = 0;
        this.y = 0;

    }

    public void comerFicha(Ficha rival) {
        if ((x == rival.getX()) && (y == rival.getY())) {
            rival.fichaComida();
        }
    }
    /*cualquier otra funcion que consideren necesaria agregar, avisenme inmediatamente
    y la discutimos todos
     */
}
