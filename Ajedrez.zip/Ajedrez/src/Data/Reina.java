/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author Nicolas
 */
public class Reina extends Ficha {

    public Reina(int x, int y, char color) {
        super('q', x, y, color);
    }

    @Override
    public void moverFicha(int x, int y) {
        if ((x < 1) || (x > 8) || (y < 1) || (y > 8) || (super.getX() == 0)) {
            System.out.println("error");
            //}else if(hayFicha()){
        } else if ((x == super.getX()) && (y == super.getY())) {
            System.out.println("no se puede mover a la misma posicion");
        } else {
            for (int i = 0; i < 9; i++) {
                if (((x == super.getX()) ^ (y == super.getY())) || (((x == super.getX() + i) && (y == super.getY() - i)) || ((x == super.getX() + i) && (y == super.getY() + i)))||
                        ((x == super.getX() - i) && (y == super.getY() + i)) || ((x == super.getX() - i) && (y == super.getY() - i))) {

                    super.setPosicion(x, y);
                } else {
                    System.out.println("error");
                }
            }
        }
    }
}
