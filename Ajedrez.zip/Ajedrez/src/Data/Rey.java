/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author Nicolas
 */
public class Rey extends Ficha {

    public Rey(int x, int y, char color) {
        super('k', x, y, color);
    }

    @Override
    public void moverFicha(int x, int y) {
        if ((x < 1) || (x > 8) || (y < 1) || (y > 8) || (super.getX() == 0)) {
            System.out.println("error");
            //}else if(hayFicha()){
        } else if ((x == super.getX()) && (y == super.getY())) {
            System.out.println("no se puede mover a la misma posicion");
        } else if (((x == super.getX() + 1) || (x == super.getX() - 1) || (x == super.getX()))
                && ((y == super.getY() + 1) || (y == super.getY() - 1) || (y == super.getY()))) {

            super.setPosicion(x, y);
        } else {
            System.out.println("error");
        }
    }

    public boolean estaEnJaque() {
        return true;
    }

}
