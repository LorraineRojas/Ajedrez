/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author Nicolas
 */
public class Tablero {

    private char[][] tablero = new char[9][9];

    public Tablero() {
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {
                if ((i == 0) && (j != 0)) {
                    tablero[i][j] = (char) ((char) j + 64);
                } else if ((j == 0) && (i != 0)) {
                    tablero[i][j] = (char) ((char) 57 - i);
                } else {
                    tablero[i][j] = '_';
                }
            }
        }

    }

    public Tablero(Ficha[] Blancas, Ficha[] Negras) {
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {
                tablero[i][j] = '_';
                if ((i == 0) && (j != 0)) {
                    tablero[i][j] = (char) ((char) j + 64);
                } else if ((j == 0) && (i != 0)) {
                    tablero[i][j] = (char) ((char) 57 - i);
                } else {
                    for (int k = 0; k < Blancas.length; k++) {
                        if ((i == Blancas[k].getY()) && (j == Blancas[k].getX())) {
                            tablero[i][j] = Blancas[k].getFicha();
                        } else if ((i == Negras[k].getY()) && (j == Negras[k].getX())) {
                            tablero[i][j] = Negras[k].getFicha();

                        }

                    }

                }
            }
        }
    }

    public void setTablero(Ficha[] Blancas, Ficha[] Negras) {
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {
                tablero[i][j] = '_';
            
                if ((i == 0) && (j != 0)) {
                    tablero[i][j] = (char) ((char) j + 64);
                } else if ((j == 0) && (i != 0)) {
                    tablero[i][j] = (char) ((char) 57 - i);
                } else {
                    for (int k = 0; k < Blancas.length; k++) {
                        if ((i == Blancas[k].getY()) && (j == Blancas[k].getX())) {
                            tablero[i][j] = Blancas[k].getFicha();
                        } else if ((i == Negras[k].getY()) && (j == Negras[k].getX())) {
                            tablero[i][j] = Negras[k].getFicha();
                        }

                    }

                }
            }
        }
    }

    public char[][] getTablero() {
        return tablero;
    }
}
