/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

/**
 *
 * @author Nicolas
 */
public class AjedrezUI {

    public static void printTablero(char[][] tablero) {
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < 19; j++) {
                if (j % 2 == 0) {
                    System.out.print("|");
                } else {
                    System.out.print(tablero[i][j / 2]);
                }

            }
            System.out.println("");

        }
    }

    public static char traducirPosicionX(int x) {
        char newX = (char) ((char) x + 64);
        return newX;
    }

    public static int traducirPosicionX(char x) {
        int newX = (int) x - 64;
        return newX;
    }

    public static int traducirPosicionY(int y) {
        int newY = 9 - y;
        return newY;
    }
}
