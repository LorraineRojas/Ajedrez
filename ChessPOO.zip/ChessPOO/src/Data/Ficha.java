package Data;

import java.awt.Image;
import java.awt.Point;

/**
 *
 * @author nico
 */
public abstract class Ficha {

    private int X, Y;
    private int pixelX, pixelY;
    private Point pixelPoint = new Point();
    private boolean havelife = true;
    private PieceIcon pieceIcon;
    private Point p = new Point();

    public Image returnPieceImage() {
        return pieceIcon.returnPieceIcon();
    }

    public void setPieceImage(PieceIcon pieceIcon) {
        this.pieceIcon = pieceIcon;
    }

    public int returnX() {
        X = p.x;
        return X;
    }

    public void setPixels(int newpixelX, int newpixelY) {
        pixelPoint.x = newpixelX;
        pixelPoint.y = newpixelY;
    }

    public int getPixelX() {
        return pixelX;
    }

    public int getPixelY() {
        return pixelY;
    }

    public Point getpixelPoint() {
        return pixelPoint;
    }

    public int returnY() {
        Y = p.y;
        return Y;
    }

    public int getX() {
        return X;
    }

    public int getY() {
        return Y;
    }

    public void setPoint(Point newPoint) {

        X = p.x = newPoint.x;
        Y = p.y = newPoint.y;
    }

    public void setX(int newX) {
        X = newX;
        p.x = newX;
    }

    public void setY(int newY) {
        Y = newY;
        p.y = newY;
    }

    public Point returnPosition() {

        return (Point) p.clone();
    }

    public boolean returnLife() {
        return havelife;
    }

    public boolean Inthispostion(int x, int y) {
        if (p.x == x && p.y == y) {
            return true;
        }
        return false;
    }

    public Point GeneratePossible_Moves() {
        return new Point();
    }

    public boolean Canmove(int x, int y) {
        return true;
    }

    public boolean Canmove(int x, int y, String typeColor) {
        return true;
    }

    public boolean checkKing(int x, int y, Point othersPostion) {
        return false;
    }

    public boolean PieceInMYway(int x, int y, Point othersPostion, String typeColor) {
        return false;
    }

    public boolean PieceInMYway(int x, int y, Point othersPostion) {
        return false;
    }

    public boolean returnMyseen() {
        return false;
    }

    public void setMYseen(boolean newBoolean) {

    }

    public boolean setSeenbychecking(Point newP, String Color) {
        return false;
    }

    public String toString() {
        return "X=" + X + ",Y=" + Y;
    }
}
