package Data;

/**
 *
 * @author nico
 */
public class King extends Ficha {

    public King(String NameIcon, int startX, int startY) {

        super.setPieceImage(new PieceIcon(NameIcon));

        super.setX(startX);
        super.setY(startY);

    }

    public boolean Canmove(int x, int y) {

        if (((y == super.getY()) && (x == (super.getX() - 1))) || ((y == super.getY() - 1) && (x == (super.getX() + 1)))
                || ((y == super.getY() - 1) && (x == (super.getX() - 1))) || ((y == super.getY() + 1) && (x == (super.getX() + 1)))
                || (((y == super.getY() + 1) && x == (super.getX() - 1))) || ((y == super.getY()) && (x == (super.getX() + 1)))
                || ((y == super.getY() - 1) && x == (super.getX())) || ((y == super.getY() + 1) && (x == (super.getX())))) {

            return true;
        }

        return false;

    }

}
