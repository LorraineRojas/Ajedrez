package Data;

/**
 *
 * @author nico
 */
public class Knight extends Ficha {

    public Knight(String NameIcon, int startX, int startY) {

        super.setPieceImage(new PieceIcon(NameIcon));

        super.setX(startX);
        super.setY(startY);

    }

    public boolean Canmove(int x, int y) {

        if ((x + 1 == super.getX()) && (y + 2 == super.getY()) || (x + 1 == super.getX()) && (y - 2 == super.getY()) || (x - 1 == super.getX()) && (y + 2 == super.getY())
                || (x - 1 == super.getX()) && (y - 2 == super.getY()) || (x + 2 == super.getX()) && (y + 1 == super.getY()) || (x + 2 == super.getX()) && (y - 1 == super.getY())
                || (x - 2 == super.getX()) && (y + 1 == super.getY()) || (x - 2 == super.getX()) && (y - 1 == super.getY())) {

            return true;
        } else {
            return false;
        }

    }

}
