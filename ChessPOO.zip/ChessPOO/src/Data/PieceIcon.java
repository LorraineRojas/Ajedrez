package Data;

import java.awt.Image;
import java.awt.Toolkit;

/**
 *
 * @author nico
 */
public class PieceIcon {

    private Toolkit kit = Toolkit.getDefaultToolkit();
    private Image image;

    public PieceIcon(String NameIcon) {

        image = kit.getImage(NameIcon);
    }

    public Image returnPieceIcon() {
        return image;
    }

}
