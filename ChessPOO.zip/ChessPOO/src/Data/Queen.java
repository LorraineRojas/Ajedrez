package Data;

import java.awt.Point;

/**
 *
 * @author nico
 */
public class Queen extends Ficha {

    public Queen(String NameIcon, int startX, int startY) {

        super.setPieceImage(new PieceIcon(NameIcon));

        super.setX(startX);
        super.setY(startY);

    }

    @Override
    public boolean Canmove(int x, int y) {

        if (((y == super.getY()) && (x > (super.getX()) || (x < super.getX())))) {
            return true;

        } else if ((((y > super.getY()) || (y < super.getY())) && (x == (super.getX())))) {
            return true;
        } else if ((x - y) == (super.getX() - super.getY())) {
            return true;

        } else if ((x + y) == (super.getX() + super.getY())) {
            return true;

        } else {

            return false;
        }

    }

    @Override
    public boolean PieceInMYway(int x, int y, Point othersPostion) {
        int j = y;
        int i = x;
        if (((y == super.getY()) && (x > (super.getX()) || (x < (super.getX()))))) {
            if ((super.getX() < i)) {
                while ((i != super.getX() + 1)) {
                    i--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if ((super.getX() > i)) {
                while ((i != super.getX() - 1)) {
                    i++;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            }
        } else if ((((y > super.getY()) || (y < super.getY())) && (x == (super.getX())))) {
            if ((super.getY() < j)) {
                while ((j != super.getY() + 1)) {
                    j--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if ((super.getY() > j)) {
                while ((j != super.getY() - 1)) {
                    j++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }

            }
        } else if ((x - y) == (super.getX() - super.getY())) {
            if (x > super.getX() && y > super.getY()) {
                while ((j != super.getY() + 1) && (i != super.getX() + 1)) {
                    j--;
                    i--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if (x < super.getX() && y < super.getY()) {
                while ((j != super.getY() - 1) && (i != super.getX() - 1)) {
                    j++;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }
            }
        } else if ((x + y) == (super.getX() + super.getY())) {

            if ((super.getX() < i) && (super.getY() > j)) {
                while ((j != super.getY() - 1) && (i != super.getX() + 1)) {
                    j++;
                    i--;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }

            } else if ((super.getX() - 1 > i) && (super.getY() < j)) {
                while ((j != super.getY() + 1) && (i != super.getX() - 1)) {
                    j--;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            }

        }
        return false;
    }

    @Override
    public boolean checkKing(int x, int y, Point othersPostion) {
        int j = y;
        int i = x;
        if (((y == super.getY()) && (x > (super.getX()) || (x < (super.getX()))))) {
            if ((super.getX() < i)) {
                while ((i != super.getX())) {
                    i--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if ((super.getX() > i)) {
                while ((i != super.getX())) {
                    i++;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            }
        } else if ((((y > super.getY()) || (y < super.getY())) && (x == (super.getX())))) {
            if ((super.getY() < j)) {
                while ((j != super.getY())) {
                    j--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if ((super.getY() > j)) {
                while ((j != super.getY())) {
                    j++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }

            }
        } else if ((x - y) == (super.getX() - super.getY())) {
            if (x > super.getX() && y > super.getY()) {
                while ((j != super.getY()) && (i != super.getX())) {
                    j--;
                    i--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if (x < super.getX() && y < super.getY()) {
                while ((j != super.getY()) && (i != super.getX())) {
                    j++;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }
            }
        } else if ((x + y) == (super.getX() + super.getY())) {

            if ((super.getX() < i) && (super.getY() > j)) {
                while ((j != super.getY()) && (i != super.getX())) {
                    j++;
                    i--;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }

            } else if ((super.getX() > i) && (super.getY() < j)) {
                while ((j != super.getY()) && (i != super.getX())) {
                    j--;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            }

        }
        return false;
    }

}
