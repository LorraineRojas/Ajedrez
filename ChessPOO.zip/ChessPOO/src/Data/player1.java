package Data;

import java.awt.Image;
import java.awt.Point;
import java.util.LinkedList;

/**
 *
 * @author nico
 */
public class player1 {

    public Rook WC1;
    public Rook WC2;
    public Knight WH1;
    public Knight WH2;
    public Queen WQ;
    public Bishop WE1;
    public Bishop WE2;
    public Pawn[] WS = new Pawn[8];
    public King WK;
    private int inHand = -1;
    private boolean kingischeck = false;
    private int choosenOne;
    String Color = "white";
    private Point other;
    int ate_to_protect;
    private LinkedList<Ficha> fichas = new LinkedList();

    public player1() {
        String fileSeparator = new String(System.getProperty("file.separator"));
        WC1 = new Rook("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player1" + fileSeparator + "wr.gif", 8, 8);
        WC2 = new Rook("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player1" + fileSeparator + "wr.gif", 1, 8);
        WH1 = new Knight("src" + fileSeparator + "UI" + fileSeparator +"Icons" + fileSeparator + "Player1" + fileSeparator + "wn.gif", 2, 8);
        WH2 = new Knight("src" + fileSeparator + "UI" + fileSeparator +"Icons" + fileSeparator + "Player1" + fileSeparator + "wn.gif", 7, 8);
        WE1 = new Bishop("src" + fileSeparator + "UI" + fileSeparator +"Icons" + fileSeparator + "Player1" + fileSeparator + "wb.gif", 3, 8);
        WE2 = new Bishop("src" + fileSeparator + "UI" + fileSeparator +"Icons" + fileSeparator + "Player1" + fileSeparator + "wb.gif", 6, 8);
        WQ = new Queen("src" + fileSeparator + "UI" + fileSeparator +"Icons" + fileSeparator + "Player1" + fileSeparator + "wq.gif", 4, 8);
        WK = new King("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player1" + fileSeparator + "wk.gif", 5, 8);
        int j = 1;
        for (int i = 0; i <= 7; i++, j++) {
            WS[i] = new Pawn("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player1" + fileSeparator + "wp.gif", j, 7);
        }

        fichas.add(WC1);
        fichas.add(WC2);
        fichas.add(WH1);
        fichas.add(WH2);
        fichas.add(WE1);
        fichas.add(WE2);
        fichas.add(WQ);
        fichas.add(WK);
        for (int i = 0; i < WS.length; i++) {
            fichas.add(WS[i]);

        }
    }

    public Point returnPosition(int i) {
        System.out.println(i);
        int j = i - 17;

        System.out.println(j);
        if ((j >= 0) && (j < 16)) {
            return fichas.get(j).returnPosition();
        }
        return new Point(-1, -1);

    }

    public Image returnIconImage(int i) {
        i -= 17;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(i).returnPieceImage();
        } else {
            return null;
        }

    }

    public void changePosition(Point newPoint, int i) {
        i -= 17;
        if ((i >= 0) && (i < 16)) {
            fichas.get(i).setPoint(newPoint);
        }

    }

    public void changePixel(int newPixelX, int newPixelY) {

        fichas.get(choosenOne).setPixels(newPixelX, newPixelY);

    }

    public Point getPixelPoint(int i) {
        i -= 17;
        choosenOne = i;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(choosenOne).getpixelPoint();

        } else {
            return null;
        }
    }

    public void changePixel(int newPixelX, int newPixelY, int i) {
        i -= 17;
        choosenOne = i;
        fichas.get(choosenOne).setPixels(newPixelX, newPixelY);
    }

    public boolean checkthemove(Point newP, int i) {
        i -= 17;
        choosenOne = i;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(choosenOne).Canmove(newP.x, newP.y);
        } else {
            return false;
        }

    }

    public boolean setSeentoPawn(int i, Point P) {
        if ((i < 33) || (i > 24)) {
            i -= 25;
            return WS[i].setSeenbychecking(P, "white");
        } else {
            return false;
        }
    }

    public boolean returnPawnSeen(int i) {
        if ((i < 17) || (i > 8)) {
            i -= 9;
            return WS[i].returnMyseen();
        } else {
            return false;
        }
    }

    public boolean checktheWay(Point newP, Point positionFromOthers, int i) {
        i -= 17;
        if (((i > -1) && (i < 2)) || ((i > 3) && (i < 7))) {
            return fichas.get(i).PieceInMYway(newP.x, newP.y, positionFromOthers);
        } else if ((i > 7) && (i <= 15)) {
            return fichas.get(i).PieceInMYway(newP.x, newP.y, positionFromOthers, Color);
        }
        return false;

    }

    public boolean Killedpiece(int i) {
        Point out = new Point(20, 20);
        i -= 17;
        if (((i < 16) && (i > 7)) || ((i < 7) && (i >= 0))) {
            fichas.get(i).setPoint(out);
            return true;
        } else if (i == 7) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checKing(Point p1, Point p2, int i) {
        i -= 17;
        if (((i > -1) && (i < 2)) || ((i > 3) && (i < 7))) {
            fichas.get(i).checkKing(p1.x, p1.y, p2);
        } else if ((i > 7) && (i <= 15)) {
            fichas.get(i).Canmove(p1.x, p1.y);
        }
        return false;

    }

    public int returnChosen() {
        return choosenOne;
    }

    public void SetInhand(int i) {
        inHand = i;
    }

    public int GetInhand() {
        return inHand;
    }

    public boolean CanMove(int x, int y) {
        return true;
    }

    public void checkKing(boolean newkingcheck) {
        kingischeck = newkingcheck;
    }

    public boolean returncheckKing() {

        return kingischeck;
    }

    public boolean if_MyKing_In_check(player2 Black) {
        boolean isCheckmate = false;
        boolean flag = false;

        return false;
    }

    public boolean Check_Mate_GameOver(player2 Enemy) {

        if (!KingGenerate_moves(Enemy)) {

            inHand = -1;
            return false;
        } else if (!RookGenerate_moves(Enemy, WC1)) {

            inHand = -1;
            return false;
        } else if (!RookGenerate_moves(Enemy, WC2)) {

            inHand = -1;
            return false;
        } else if (!BishopGenerate_moves(Enemy, WE1)) {

            inHand = -1;
            return false;
        } else if (!BishopGenerate_moves(Enemy, WE2)) {

            inHand = -1;
            return false;
        } else if (!KnightGenerate_moves(Enemy, WH1)) {

            inHand = -1;
            return false;
        } else if (!KnightGenerate_moves(Enemy, WH2)) {

            inHand = -1;
            return false;
        } else if (!QueenGenerate_moves(Enemy)) {

            inHand = -1;
            return false;
        }

        for (int i = 0; i <= 7; i++) {
            inHand = 25 + i;
            if (!PawnGenerate_moves(Enemy, WS[i])) {

                inHand = -1;
                System.out.println("I Killed Solider 1");
                return false;
            }
        }

        inHand = -1;
        return true;

    }

    public boolean see_king_Check(player2 Black) {

        Point My_King_Postion = WK.returnPosition();
        boolean flag = false;

        for (int i = 1; i < 17; i++) {
            if (i < 9) {
                if (Black.checkthemove(My_King_Postion, i)) {

                    flag = true;
                    for (int j = 1; j < 33; j++) {

                        if (j < 17) {

                            if (Black.checktheWay(My_King_Postion, Black.returnPosition(j), i)) {

                                flag = false;

                            }
                        } else if (j != 24) {
                            if (Black.checktheWay(My_King_Postion, returnPosition(j), i)) {

                                flag = false;

                            }
                        }

                    }

                    if (flag) {

                        break;
                    }

                }
            } else if (Black.setSeentoPawn(i, My_King_Postion)) {

                break;

            }

            if (i == 16) {

                return false;
            }
        }

        return true;
    }

    public boolean Piece_already_there(Point newP) {
        Point samePostion;
        for (int i = 17; i <= 32; i++) {
            if (GetInhand() != i) {

                samePostion = returnPosition(i);
                if (newP.x == samePostion.x && newP.y == samePostion.y) {

                    return false;

                }
            }
        }

        return true;
    }

    public boolean Pice_already_there_from_enemy(Point newP, player2 enemy) {
        Point samePostion;
        for (int i = 1; i <= 16; i++) {
            samePostion = enemy.returnPosition(i);
            if (newP.x == samePostion.x && newP.y == samePostion.y) {

                return false;

            }
        }

        return true;
    }

    public int Get_Pice_already_there_from_enemy(Point newP, player2 enemy) {
        Point samePostion;
        for (int i = 1; i <= 16; i++) {
            samePostion = enemy.returnPosition(i);
            if (newP.x == samePostion.x && newP.y == samePostion.y) {

                return i;

            }
        }

        return -1;
    }

    public boolean KingGenerate_moves(player2 enemy) {
        boolean something_killed = false;
        Point Oldp = new Point();

        Point PlaceCheck = new Point();
        inHand = 24;

        int x = WK.returnX();
        int y = WK.returnY();
        Oldp.x = x;
        Oldp.y = y;

        if (x + 1 <= 8) {

            WK.setX(x + 1);
            WK.setY(y);
            PlaceCheck.x = x + 1;
            PlaceCheck.y = y;

            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    WK.setPoint(Oldp);
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    return false;
                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y + 1 <= 8) {

            WK.setX(x);
            WK.setY(y + 1);
            PlaceCheck.x = x;
            PlaceCheck.y = y + 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    WK.setPoint(Oldp);
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    return false;

                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        if (y - 1 > 0) {

            WK.setX(x);
            WK.setY(y - 1);

            PlaceCheck.x = x;
            PlaceCheck.y = y - 1;

            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }

            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    WK.setPoint(Oldp);
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }

                    return false;
                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (x - 1 > 0) {

            WK.setX(x - 1);
            WK.setY(y);

            PlaceCheck.x = x - 1;
            PlaceCheck.y = y;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    WK.setPoint(Oldp);
                    return false;
                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y - 1 > 0 && x - 1 > 0) {

            WK.setX(x - 1);
            WK.setY(y - 1);

            PlaceCheck.x = x - 1;
            PlaceCheck.y = y - 1;

            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    WK.setPoint(Oldp);
                    return false;
                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y + 1 <= 8 && x + 1 <= 8) {

            WK.setX(x + 1);
            WK.setY(y + 1);

            PlaceCheck.x = x + 1;
            PlaceCheck.y = y + 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    WK.setPoint(Oldp);
                    return false;
                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y - 1 > 0 && x + 1 <= 8) {

            WK.setX(x + 1);
            WK.setY(y - 1);

            PlaceCheck.x = x + 1;
            PlaceCheck.y = y - 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    WK.setPoint(Oldp);
                    return false;
                }
            }

        }
        WK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y + 1 <= 8 && x - 1 > 0) {

            WK.setX(x - 1);
            WK.setY(y + 1);

            PlaceCheck.x = x - 1;
            PlaceCheck.y = y + 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    WK.setPoint(Oldp);
                    return false;
                }
            }

        }

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        WK.setPoint(Oldp);
        return true;

    }

    public boolean RookGenerate_moves(player2 enemy, Rook WC) {
        boolean something_killed = false;
        Point Oldp1 = new Point();

        Point PlaceCheck = new Point();
        int x1 = WC.returnX();
        int y1 = WC.returnY();

        if (WC == WC1) {
            inHand = 17;
        } else {
            inHand = 18;
        }

        Oldp1.x = x1;
        Oldp1.y = y1;

        PlaceCheck.y = y1;

        if (x1 != 20) {
            for (int i = 1; i <= 8; i++) {
                WC.setX(i);
                PlaceCheck.x = i;

                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            WC.setX(Oldp1.x);
                            WC.setY(Oldp1.y);

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            WC.setX(Oldp1.x);
            PlaceCheck.x = Oldp1.x;

            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }
            for (int i = 1; i <= 8; i++) {
                WC.setY(i);
                PlaceCheck.y = i;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            WC.setX(Oldp1.x);
                            WC.setY(Oldp1.y);

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            WC.setY(Oldp1.y);
        }

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        WC.setX(Oldp1.x);
        WC.setY(Oldp1.y);
        return true;
    }

    public boolean BishopGenerate_moves(player2 enemy, Bishop WE) {
        boolean something_killed = false;
        Point Oldp1 = new Point();
        Point PlaceCheck = new Point();

        Oldp1 = WE.returnPosition();

        if (WE == WE1) {
            inHand = 21;
        } else {
            inHand = 22;
        }

        if (Oldp1.x != 20) {
            for (int x = Oldp1.x, y = Oldp1.y; x >= 1 && y <= 8; x--, y++) {

                WE.setX(x);
                WE.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            WE.setPoint(Oldp1);
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }
            for (int x = Oldp1.x, y = Oldp1.y; y >= 1 && x <= 8; x++, y--) {

                WE.setX(x);
                WE.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            WE.setPoint(Oldp1);
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            WE.setPoint(Oldp1);

        }

        WE.setPoint(Oldp1);

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        return true;
    }

    public boolean KnightGenerate_moves(player2 enemy, Knight WH) {
        Point oldp1 = new Point();
        boolean somthing_killed = false;
        oldp1 = WH.returnPosition();

        Point PlaceCheck = new Point();

        if (WH == WH1) {
            inHand = 19;
        } else {
            inHand = 20;
        }

        int x = oldp1.x;
        int y = oldp1.y;

        if (x != 20) {

            if (x + 1 <= 8 && y + 1 <= 8) {
                WH.setX(x + 1);
                WH.setY(y + 2);
                PlaceCheck.x = x + 1;
                PlaceCheck.y = y + 2;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        WH.setPoint(oldp1);

                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }

                        return false;
                    }
                }
            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            if (x + 1 <= 8 && y - 2 >= 1) {
                WH.setX(x + 1);
                WH.setY(y - 2);
                PlaceCheck.x = x + 1;
                PlaceCheck.y = y - 2;
                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            if (x + 2 <= 8 && y + 1 <= 8) {
                WH.setX(x + 2);
                WH.setY(y + 1);
                PlaceCheck.x = x + 2;
                PlaceCheck.y = y + 1;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }

            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }
            if (x + 2 <= 8 && y - 1 >= 1) {
                WH.setX(x + 2);
                WH.setY(y - 1);
                PlaceCheck.x = x + 2;
                PlaceCheck.y = y - 1;
                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            if (x - 1 >= 1 && y + 2 <= 8) {
                WH.setX(x - 1);
                WH.setY(y + 2);
                PlaceCheck.x = x - 1;
                PlaceCheck.y = y + 2;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            if (x - 1 >= 1 && y - 2 >= 1) {
                WH.setX(x - 1);
                WH.setY(y - 2);
                PlaceCheck.x = x - 1;
                PlaceCheck.y = y - 2;
                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            if (x - 2 >= 1 && y + 1 <= 8) {
                WH.setX(x - 2);
                WH.setY(y + 1);
                PlaceCheck.x = x - 2;
                PlaceCheck.y = y + 1;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }
                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }

            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            if (x - 2 >= 1 && y - 1 >= 1) {
                WH.setX(x - 2);
                WH.setY(y - 1);
                PlaceCheck.x = x - 2;
                PlaceCheck.y = y - 1;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    somthing_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (somthing_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            somthing_killed = false;
                        }
                        WH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

        }
        WH.setPoint(oldp1);

        return true;
    }

    public boolean QueenGenerate_moves(player2 enemy) {
        boolean somthing_killed = false;

        Point Oldp1 = new Point();

        Oldp1 = WQ.returnPosition();

        Point PlaceCheck = new Point();

        inHand = 23;

        if (Oldp1.x != 20) {
            for (int x = Oldp1.x, y = Oldp1.y; x >= 1 && y <= 8; x--, y++) {

                WQ.setX(x);
                WQ.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        somthing_killed = true;
                    }

                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            WQ.setPoint(Oldp1);

                            if (somthing_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                somthing_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (somthing_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    somthing_killed = false;
                }

            }
            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }
            for (int x = Oldp1.x, y = Oldp1.y; y >= 1 && x <= 8; x++, y--) {

                WQ.setX(x);
                WQ.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        somthing_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            WQ.setPoint(Oldp1);
                            if (somthing_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                somthing_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (somthing_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    somthing_killed = false;
                }

            }
            WQ.setPoint(Oldp1);
            PlaceCheck.x = Oldp1.x;
            PlaceCheck.y = Oldp1.y;

            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            for (int i = 1; i <= 8; i++) {
                WQ.setX(i);

                PlaceCheck.x = i;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        somthing_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            WQ.setX(Oldp1.x);
                            if (somthing_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                somthing_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (somthing_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    somthing_killed = false;
                }

            }
            WQ.setX(Oldp1.x);
            PlaceCheck.x = Oldp1.x;

            if (somthing_killed) {
                enemy.changePosition(other, ate_to_protect);
                somthing_killed = false;
            }

            for (int i = 1; i <= 8; i++) {
                WQ.setY(i);
                PlaceCheck.y = i;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        somthing_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            WQ.setY(Oldp1.y);
                            if (somthing_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                somthing_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (somthing_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    somthing_killed = false;
                }

            }
            WQ.setY(Oldp1.y);
        }

        if (somthing_killed) {
            enemy.changePosition(other, ate_to_protect);
            somthing_killed = false;
        }

        return true;

    }

    public boolean PawnGenerate_moves(player2 enemy, Pawn Sold) {
        Point Oldp1 = new Point();
        Oldp1 = Sold.returnPosition();
        Point PlaceCheck = new Point();
        PlaceCheck.x = Oldp1.x;
        PlaceCheck.y = Oldp1.y;

        if (Oldp1.x != 20) {
            if (Sold.Canmove(Oldp1.x, Oldp1.y - 2, Color) && Oldp1.y - 2 >= 1) {
                Sold.setY(Oldp1.y - 2);

                PlaceCheck.y = Oldp1.y - 1;

                if (Piece_already_there(PlaceCheck)) {
                    if (Pice_already_there_from_enemy(PlaceCheck, enemy)) {
                        if (!see_king_Check(enemy)) {

                            Sold.setPoint(Oldp1);
                            return false;
                        }
                    }
                }

            }
            if (Sold.Canmove(Oldp1.x, Oldp1.y - 1, Color) && Oldp1.y - 1 >= 1) {
                Sold.setY(Oldp1.y - 1);
                PlaceCheck.y = Oldp1.y - 1;

                if (Piece_already_there(PlaceCheck)) {
                    if (Pice_already_there_from_enemy(PlaceCheck, enemy)) {

                        if (!see_king_Check(enemy)) {
                            Sold.setPoint(Oldp1);
                            System.out.println("dff");
                            System.out.println("dff");
                            System.out.println("dff");
                            return false;
                        }
                    }
                }
            }

            if (!Pice_already_there_from_enemy(new Point(Oldp1.x - 1, Oldp1.y - 1), enemy)) {
                if (kill_to_protect_king(enemy, new Point(Oldp1.x - 1, Oldp1.y - 1))) {

                    if (!see_king_Check(enemy)) {
                        enemy.changePosition(other, ate_to_protect);
                        Sold.setPoint(Oldp1);

                        return false;
                    }
                    enemy.changePosition(other, ate_to_protect);
                }
            }

            if (!Pice_already_there_from_enemy(new Point(Oldp1.x + 1, Oldp1.y - 1), enemy)) {
                if (kill_to_protect_king(enemy, new Point(Oldp1.x + 1, Oldp1.y - 1))) {
                    if (!see_king_Check(enemy)) {
                        enemy.changePosition(other, ate_to_protect);
                        Sold.setPoint(Oldp1);

                        return false;
                    }
                    enemy.changePosition(other, ate_to_protect);

                }
            }

        }

        Sold.setPoint(Oldp1);
        return true;
    }

    public boolean Check_The_Way_to_Postion(player2 enemy, Point newP) {
        boolean flag = false;

        for (int i = 1; i <= 32; i++) {
            if (inHand != i) {
                if (i < 17) {
                    flag = checktheWay(newP, enemy.returnPosition(i), inHand);
                } else {
                    flag = checktheWay(newP, returnPosition(i), inHand);
                }

                if (flag == true) {
                    return false;
                }
            }
        }
        return true;

    }

    public boolean kill_to_protect_king(player2 enemy, Point newP) {

        for (int i = 1; i < 17; i++) {

            other = enemy.returnPosition(i);
            if (other.x == newP.x && other.y == newP.y) {
                ate_to_protect = i;

                enemy.Killedpiece(i);
                return true;
            }
        }

        return false;
    }

}
