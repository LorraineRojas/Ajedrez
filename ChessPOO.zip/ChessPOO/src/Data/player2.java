package Data;

import java.awt.Image;
import java.awt.Point;
import java.util.Enumeration;
import java.util.LinkedList;

/**
 *
 * @author nico
 */
public class player2 {

    public Rook BC1;
    public Rook BC2;
    public Knight BH1;
    public Knight BH2;
    public Bishop BE1;
    public Bishop BE2;
    public Queen BQ;
    private King BK;
    public Pawn[] BS = new Pawn[8];
    private int choosenOne;
    private int inHand = -1;
    private boolean kingischeck = false;
    private Point other;
    private int ate_to_protect;

    private String Color = "black";
    private LinkedList<Ficha> fichas = new LinkedList();

    /**
     * Creates a new instance of player2
     */
    public player2() {
        String fileSeparator = new String(System.getProperty("file.separator"));
        BC1 = new Rook("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "br.gif", 1, 1);
        BC2 = new Rook("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "br.gif", 8, 1);
        BH1 = new Knight("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bn.gif", 2, 1);
        BH2 = new Knight("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bn.gif", 7, 1);
        BE1 = new Bishop("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bb.gif", 3, 1);
        BE2 = new Bishop("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bb.gif", 6, 1);
        BQ = new Queen("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bq.gif", 4, 1);
        BK = new King("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bk.gif", 5, 1);
        int j = 1;
        for (int i = 0; i <= 7; i++, j++) {
            BS[i] = new Pawn("src" + fileSeparator + "UI" + fileSeparator + "Icons" + fileSeparator + "Player2" + fileSeparator + "bp.gif", j, 2);
        }
        fichas.add(BC1);
        fichas.add(BC2);
        fichas.add(BH1);
        fichas.add(BH2);
        fichas.add(BE1);
        fichas.add(BE2);
        fichas.add(BQ);
        fichas.add(BK);
        for (int i = 0; i < BS.length; i++) {
            fichas.add(BS[i]);

        }
    }

    public void setChoosen(int newChoosen) {
        choosenOne = newChoosen;
    }

    public Point returnPosition(int i) {

        i -= 1;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(i).returnPosition();
        } else {

            return new Point(-1, -1);
        }

    }

    public Image returnIconImage(int i) {
        i -= 1;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(i).returnPieceImage();
        } else {
            return null;
        }

    }

    public void changePosition(Point newPoint, int i) {
        i -= 1;
        if ((i >= 0) && (i < 16)) {
            fichas.get(i).setPoint(newPoint);
        }

    }

    public void changePixel(int newPixelX, int newPixelY) {

        fichas.get(choosenOne).setPixels(newPixelX, newPixelY);

    }

    public Point getPixelPoint(int i) {
        i -= 1;
        choosenOne = i;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(choosenOne).getpixelPoint();

        } else {
            return null;
        }
    }

    public void changePixel(int newPixelX, int newPixelY, int i) {
        i -= 1;
        choosenOne = i;
        fichas.get(choosenOne).setPixels(newPixelX, newPixelY);
    }

    public boolean Killedpiece(int i) {
        Point out = new Point(20, 20);
        i -= 1;
        if (((i < 16) && (i > 7)) || ((i < 7) && (i >= 0))) {
            fichas.get(i).setPoint(out);
            return true;
        } else if (i == 7) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkthemove(Point newP, int i) {
        i -= 1;
        choosenOne = i;
        if ((i >= 0) && (i < 16)) {
            return fichas.get(choosenOne).Canmove(newP.x, newP.y);
        } else {
            return false;
        }

    }

    public boolean setSeentoPawn(int i, Point P) {
        if ((i < 17) || (i > 8)) {
            i -= 9;
            return BS[i].setSeenbychecking(P, "black");
        } else {
            return false;
        }
    }

    public boolean returnPawnSeen(int i) {
        if ((i < 17) || (i > 8)) {
            i -= 9;
            return BS[i].returnMyseen();
        } else {
            return false;
        }
    }

    public boolean checktheWay(Point newP, Point positionFromOthers, int i) {
        i -= 1;
        if (((i > -1) && (i < 2)) || ((i > 3) && (i < 7))) {
            return fichas.get(i).PieceInMYway(newP.x, newP.y, positionFromOthers);
        } else if ((i > 7) && (i <= 15)) {
            return fichas.get(i).PieceInMYway(newP.x, newP.y, positionFromOthers, Color);
        }
        return false;

    }

    public boolean checKing(Point p1, Point p2, int i) {
        i -= 1;
        if (((i > -1) && (i < 2)) || ((i > 3) && (i < 7))) {
            fichas.get(i).checkKing(p1.x, p1.y, p2);
        } else if ((i > 7) && (i <= 15)) {
            fichas.get(i).Canmove(p1.x, p1.y);
        }
        return false;

    }

    public int returnChosen() {
        return choosenOne;
    }

    public void SetInhand(int i) {
        inHand = i;
    }

    public int GetInhand() {
        return inHand;
    }

    public boolean CanMove(int x, int y) {
        return true;
    }

    public void checkKing(boolean newkingcheck) {
        kingischeck = newkingcheck;
    }

    public boolean returncheckKing() {
        return kingischeck;
    }

    public boolean see_king_Check(player1 White) {

        Point My_King_Position = BK.returnPosition();
        boolean flag = false;
        for (int i = 17; i < 33; i++) {
            if (i < 25) {
                if (White.checkthemove(My_King_Position, i)) {

                    flag = true;
                    for (int j = 1; j < 33; j++) {

                        if (j < 17) {

                            if (White.checktheWay(My_King_Position, returnPosition(j), i)) {

                                flag = false;

                            }
                        } else if (j != 8) {
                            if (White.checktheWay(My_King_Position, White.returnPosition(j), i)) {

                                flag = false;

                            }
                        }

                    }

                    if (flag) {

                        break;
                    }

                }
            } else if (White.setSeentoPawn(i, My_King_Position)) {

                break;

            }

            if (i == 32) {

                return false;
            }
        }

        return true;
    }

    public boolean Check_Mate_GameOver(player1 Enemy) {

        if (!KingGenerate_moves(Enemy)) {

            inHand = -1;

            return false;
        } else if (!RookGenerate_moves(Enemy, BC1)) {

            inHand = -1;

            return false;
        } else if (!RookGenerate_moves(Enemy, BC2)) {

            inHand = -1;

            return false;
        } else if (!BishopGenerate_moves(Enemy, BE1)) {

            inHand = -1;

            return false;
        } else if (!BishopGenerate_moves(Enemy, BE2)) {

            inHand = -1;

            return false;
        } else if (!KnightGenerate_moves(Enemy, BH1)) {

            inHand = -1;

            return false;
        } else if (!KnightGenerate_moves(Enemy, BH2)) {

            inHand = -1;

            return false;
        } else if (!QueenGenerate_moves(Enemy)) {

            inHand = -1;

            return false;
        }

        for (int i = 0; i <= 7; i++) {
            inHand = 9 + i;
            if (!PawnGenerate_moves(Enemy, BS[i])) {

                inHand = -1;

                return false;
            }
        }

        inHand = -1;
        return true;

    }

    public boolean Piece_already_there(Point newP) {
        Point samePostion;
        for (int i = 1; i <= 16; i++) {
            if (GetInhand() != i) {

                samePostion = returnPosition(i);
                if (newP.x == samePostion.x && newP.y == samePostion.y) {

                    return false;

                }
            }
        }

        return true;
    }

    public boolean Pice_already_there_from_enemy(Point newP, player1 enemy) {
        Point samePosition;
        for (int i = 17; i <= 32; i++) {

            samePosition = enemy.returnPosition(i);
            if (newP.x == samePosition.x && newP.y == samePosition.y) {

                return false;

            }

        }

        return true;
    }

    public int Get_Pice_already_there_from_enemy(Point newP, player1 enemy) {
        Point samePosition;
        for (int i = 17; i <= 32; i++) {
            samePosition = enemy.returnPosition(i);
            if (newP.x == samePosition.x && newP.y == samePosition.y) {
                return i;
            }
        }
        return -1;
    }

    public boolean KingGenerate_moves(player1 enemy) {
        boolean something_killed = false;
        Point Oldp = new Point();

        Point PlaceCheck = new Point();
        inHand = 8;

        int x = BK.returnX();
        int y = BK.returnY();

        Oldp.x = x;
        Oldp.y = y;

        if (x + 1 <= 8) {

            BK.setX(x + 1);
            BK.setY(y);
            PlaceCheck.x = x + 1;
            PlaceCheck.y = y;

            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    BK.setPoint(Oldp);
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    return false;
                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y + 1 <= 8) {

            BK.setX(x);
            BK.setY(y + 1);
            PlaceCheck.x = x;
            PlaceCheck.y = y + 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    BK.setPoint(Oldp);
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    return false;

                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        if (y - 1 > 0) {

            BK.setX(x);
            BK.setY(y - 1);

            PlaceCheck.x = x;
            PlaceCheck.y = y - 1;

            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }

            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    BK.setPoint(Oldp);
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }

                    return false;
                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (x - 1 > 0) {

            BK.setX(x - 1);
            BK.setY(y);

            PlaceCheck.x = x - 1;
            PlaceCheck.y = y;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    BK.setPoint(Oldp);
                    return false;
                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y - 1 > 0 && x - 1 > 0) {

            BK.setX(x - 1);
            BK.setY(y - 1);

            PlaceCheck.x = x - 1;
            PlaceCheck.y = y - 1;

            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    BK.setPoint(Oldp);
                    return false;
                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y + 1 <= 8 && x + 1 <= 8) {

            BK.setX(x + 1);
            BK.setY(y + 1);

            PlaceCheck.x = x + 1;
            PlaceCheck.y = y + 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {

                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    BK.setPoint(Oldp);
                    return false;
                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y - 1 > 0 && x + 1 <= 8) {

            BK.setX(x + 1);
            BK.setY(y - 1);

            PlaceCheck.x = x + 1;
            PlaceCheck.y = y - 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    BK.setPoint(Oldp);
                    return false;
                }
            }

        }
        BK.setPoint(Oldp);
        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        if (y + 1 <= 8 && x - 1 > 0) {

            BK.setX(x - 1);
            BK.setY(y + 1);

            PlaceCheck.x = x - 1;
            PlaceCheck.y = y + 1;
            if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                something_killed = true;
            }
            if (Piece_already_there(PlaceCheck)) {
                if (!see_king_Check(enemy)) {
                    if (something_killed) {
                        enemy.changePosition(other, ate_to_protect);
                        something_killed = false;
                    }
                    BK.setPoint(Oldp);
                    return false;
                }
            }

        }

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        BK.setPoint(Oldp);
        return true;

    }

    public boolean RookGenerate_moves(player1 enemy, Rook BC) {
        boolean something_killed = false;
        Point Oldp1 = new Point();

        Point PlaceCheck = new Point();
        int x1 = BC.returnX();
        int y1 = BC.returnY();

        if (BC == BC1) {
            inHand = 1;
        } else {
            inHand = 2;
        }

        Oldp1.x = x1;
        Oldp1.y = y1;

        PlaceCheck.y = y1;

        if (x1 != 20) {
            for (int i = 1; i <= 8; i++) {

                BC.setX(i);
                PlaceCheck.x = i;

                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }

                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            BC.setX(Oldp1.x);
                            BC.setY(Oldp1.y);

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            BC.setX(Oldp1.x);
            PlaceCheck.x = Oldp1.x;

            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }
            for (int i = 1; i <= 8; i++) {
                BC.setY(i);
                PlaceCheck.y = i;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            BC.setX(Oldp1.x);
                            BC.setY(Oldp1.y);

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            BC.setY(Oldp1.y);
        }

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }
        BC.setX(Oldp1.x);
        BC.setY(Oldp1.y);
        return true;
    }

    public boolean BishopGenerate_moves(player1 enemy, Bishop BE) {
        boolean something_killed = false;
        Point Oldp1 = new Point();
        Point PlaceCheck = new Point();

        Oldp1 = BE.returnPosition();

        if (BE == BE1) {
            inHand = 5;
        } else {
            inHand = 6;
        }

        if (Oldp1.x != 20) {
            for (int x = Oldp1.x, y = Oldp1.y; x >= 1 && y <= 8; x--, y++) {

                BE.setX(x);
                BE.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            BE.setPoint(Oldp1);
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }
            for (int x = Oldp1.x, y = Oldp1.y; y >= 1 && x <= 8; x++, y--) {

                BE.setX(x);
                BE.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            BE.setPoint(Oldp1);
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            BE.setPoint(Oldp1);

        }

        BE.setPoint(Oldp1);

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        return true;
    }

    public boolean KnightGenerate_moves(player1 enemy, Knight BH) {
        Point oldp1 = new Point();
        boolean something_killed = false;
        oldp1 = BH.returnPosition();

        Point PlaceCheck = new Point();

        if (BH == BH1) {
            inHand = 3;
        } else {
            inHand = 4;
        }

        int x = oldp1.x;
        int y = oldp1.y;

        if (x != 20) {

            if (x + 1 <= 8 && y + 1 <= 8) {
                BH.setX(x + 1);
                BH.setY(y + 2);
                PlaceCheck.x = x + 1;
                PlaceCheck.y = y + 2;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        BH.setPoint(oldp1);

                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }

                        return false;
                    }
                }
            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            if (x + 1 <= 8 && y - 2 >= 1) {
                BH.setX(x + 1);
                BH.setY(y - 2);
                PlaceCheck.x = x + 1;
                PlaceCheck.y = y - 2;
                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            if (x + 2 <= 8 && y + 1 <= 8) {
                BH.setX(x + 2);
                BH.setY(y + 1);
                PlaceCheck.x = x + 2;
                PlaceCheck.y = y + 1;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }

            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }
            if (x + 2 <= 8 && y - 1 >= 1) {
                BH.setX(x + 2);
                BH.setY(y - 1);
                PlaceCheck.x = x + 2;
                PlaceCheck.y = y - 1;
                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            if (x - 1 >= 1 && y + 2 <= 8) {
                BH.setX(x - 1);
                BH.setY(y + 2);
                PlaceCheck.x = x - 1;
                PlaceCheck.y = y + 2;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            if (x - 1 >= 1 && y - 2 >= 1) {
                BH.setX(x - 1);
                BH.setY(y - 2);
                PlaceCheck.x = x - 1;
                PlaceCheck.y = y - 2;
                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            if (x - 2 >= 1 && y + 1 <= 8) {
                BH.setX(x - 2);
                BH.setY(y + 1);
                PlaceCheck.x = x - 2;
                PlaceCheck.y = y + 1;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }
                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }

            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            if (x - 2 >= 1 && y - 1 >= 1) {
                BH.setX(x - 2);
                BH.setY(y - 1);
                PlaceCheck.x = x - 2;
                PlaceCheck.y = y - 1;

                if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                    something_killed = true;
                }

                if (Piece_already_there(PlaceCheck)) {
                    if (!see_king_Check(enemy)) {
                        if (something_killed) {
                            enemy.changePosition(other, ate_to_protect);
                            something_killed = false;
                        }
                        BH.setPoint(oldp1);
                        return false;
                    }
                }
            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

        }
        BH.setPoint(oldp1);

        return true;
    }

    public boolean QueenGenerate_moves(player1 enemy) {
        boolean something_killed = false;

        Point Oldp1 = new Point();

        Oldp1 = BQ.returnPosition();

        Point PlaceCheck = new Point();

        inHand = 7;

        if (Oldp1.x != 20) {
            for (int x = Oldp1.x, y = Oldp1.y; x >= 1 && y <= 8; x--, y++) {

                BQ.setX(x);
                BQ.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }

                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            BQ.setPoint(Oldp1);

                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }
            for (int x = Oldp1.x, y = Oldp1.y; y >= 1 && x <= 8; x++, y--) {

                BQ.setX(x);
                BQ.setY(y);
                PlaceCheck.x = x;
                PlaceCheck.y = y;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            BQ.setPoint(Oldp1);
                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            BQ.setPoint(Oldp1);
            PlaceCheck.x = Oldp1.x;
            PlaceCheck.y = Oldp1.y;

            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            for (int i = 1; i <= 8; i++) {
                BQ.setX(i);

                PlaceCheck.x = i;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            BQ.setX(Oldp1.x);
                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            BQ.setX(Oldp1.x);
            PlaceCheck.x = Oldp1.x;

            if (something_killed) {
                enemy.changePosition(other, ate_to_protect);
                something_killed = false;
            }

            for (int i = 1; i <= 8; i++) {
                BQ.setY(i);
                PlaceCheck.y = i;
                if (Check_The_Way_to_Postion(enemy, Oldp1)) {
                    if (kill_to_protect_king(enemy, returnPosition(inHand))) {
                        something_killed = true;
                    }
                    if (Piece_already_there(PlaceCheck)) {
                        if (!see_king_Check(enemy)) {
                            BQ.setY(Oldp1.y);
                            if (something_killed) {
                                enemy.changePosition(other, ate_to_protect);
                                something_killed = false;
                            }
                            return false;
                        }
                    }
                }

                if (something_killed) {
                    enemy.changePosition(other, ate_to_protect);
                    something_killed = false;
                }

            }
            BQ.setY(Oldp1.y);
        }

        if (something_killed) {
            enemy.changePosition(other, ate_to_protect);
            something_killed = false;
        }

        return true;

    }

    public boolean PawnGenerate_moves(player1 enemy, Pawn Sold) {
        Point Oldp1 = new Point();
        Oldp1 = Sold.returnPosition();
        Point PlaceCheck = new Point();
        PlaceCheck.x = Oldp1.x;
        PlaceCheck.y = Oldp1.y;

        if (Oldp1.x != 20) {
            if (Sold.Canmove(Oldp1.x, Oldp1.y + 2, Color) && Oldp1.y + 2 >= 1) {
                Sold.setY(Oldp1.y + 2);

                PlaceCheck.y = Oldp1.y + 2;

                if (Piece_already_there(PlaceCheck)) {
                    if (Pice_already_there_from_enemy(PlaceCheck, enemy)) {
                        if (!see_king_Check(enemy)) {

                            Sold.setPoint(Oldp1);
                            return false;
                        }
                    }
                }

            }
            if (Sold.Canmove(Oldp1.x, Oldp1.y + 1, Color) && Oldp1.y + 1 >= 1) {
                Sold.setY(Oldp1.y + 1);
                PlaceCheck.y = Oldp1.y + 1;

                if (Piece_already_there(PlaceCheck)) {
                    if (Pice_already_there_from_enemy(PlaceCheck, enemy)) {
                        if (!see_king_Check(enemy)) {
                            Sold.setPoint(Oldp1);

                            return false;
                        }
                    }
                }
            }

            if (Pice_already_there_from_enemy(new Point(Oldp1.x - 1, Oldp1.y + 1), enemy)) {
                if (kill_to_protect_king(enemy, new Point(Oldp1.x - 1, Oldp1.y + 1))) {

                    if (!see_king_Check(enemy)) {
                        enemy.changePosition(other, ate_to_protect);
                        Sold.setPoint(Oldp1);

                        return false;
                    }
                    enemy.changePosition(other, ate_to_protect);
                }
            }

            if (!Pice_already_there_from_enemy(new Point(Oldp1.x + 1, Oldp1.y + 1), enemy)) {
                if (kill_to_protect_king(enemy, new Point(Oldp1.x + 1, Oldp1.y + 1))) {
                    if (!see_king_Check(enemy)) {
                        enemy.changePosition(other, ate_to_protect);
                        Sold.setPoint(Oldp1);

                        return false;
                    }
                    enemy.changePosition(other, ate_to_protect);

                }
            }

        }

        Sold.setPoint(Oldp1);
        return true;
    }

    public boolean Check_The_Way_to_Postion(player1 enemy, Point newP) {
        boolean flag = false;

        for (int i = 1; i <= 32; i++) {
            if (inHand != i)// check if there is peices in the WAY
            {
                if (i < 17) {
                    flag = checktheWay(newP, enemy.returnPosition(i), inHand);//Means there is somting in the Way so can't move
                } else {
                    flag = checktheWay(newP, returnPosition(i), inHand);
                }

                if (flag == true) {
                    return false;
                }//Means  there is a Pice in the Way
            }
        }
        return true;

    }

    public boolean kill_to_protect_king(player1 enemy, Point newP) {

        for (int i = 17; i <= 32; i++) {

            other = enemy.returnPosition(i);
            if (other.x == newP.x && other.y == newP.y) {
                ate_to_protect = i;

                enemy.Killedpiece(i);
                return true;
            }
        }

        return false;
    }

}
