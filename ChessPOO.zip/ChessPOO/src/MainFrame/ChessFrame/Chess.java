package MainFrame.ChessFrame;

import UI.MainFrame;

public class Chess {

    public static void main(String[] args) {
        MainFrame F = new MainFrame();
    }
}
