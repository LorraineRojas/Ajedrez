package UI;

import javax.swing.JMenuBar;

/**
 *
 * @author lisseth
 */
public class Chess_MainMenuBar extends JMenuBar {//menu de todas las opciones

    public Chess_MainMenuBar(MainFrame ff) {
        Fmenu = new File_Menu(ff);
        Imenu = new Instruction_Menu(ff);
        add(Fmenu);
        add(Imenu);

    }

    private final File_Menu Fmenu;
    private final Instruction_Menu Imenu;

}
