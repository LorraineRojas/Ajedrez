package UI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;

/**
 *
 * @author lisseth
 */
public class Exit_Item extends JMenuItem { //opcion para salir del juego del menu

    public Exit_Item() {
        setText("Salir");
        addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

    }

}
