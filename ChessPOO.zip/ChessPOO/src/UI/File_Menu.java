package UI;

import javax.swing.JMenu;

/**
 *
 * @author lisseth
 */
public class File_Menu extends JMenu {//menu de archivo

    public File_Menu(MainFrame ff) {
        NItem = new New_Item(ff);
        setText("Archivo");

        add(NItem);
        addSeparator();
        add(SItem);
        add(LItem);
        add(EItem);
        SItem.setEnabled(false);
        LItem.setEnabled(false);
    }

    private final New_Item NItem;
    private final Save_Item SItem = new Save_Item();
    private final Load_Item LItem = new Load_Item();
    private final Exit_Item EItem = new Exit_Item();

}
