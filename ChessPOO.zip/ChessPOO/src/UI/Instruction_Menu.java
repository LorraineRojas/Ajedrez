package UI;

import javax.swing.JMenu;

/**
 *
 * @author lisseth
 */
public class Instruction_Menu extends JMenu {//menu de archivo

    public Instruction_Menu(MainFrame ff) {

        setText("Help");

        add(FFItem);
        add(AItem);

    }

    private final FileInstruction_Item FFItem = new FileInstruction_Item();
    private final Autor_Item AItem = new Autor_Item();
}
