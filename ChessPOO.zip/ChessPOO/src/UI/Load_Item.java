package UI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;

/**
 *
 * @author lisseth
 */
public class Load_Item extends JMenuItem {//clase para correr juego guardado

    public Load_Item() {
        setText("Cargar juego");
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoadFile.showOpenDialog(null);
            }
        });
    }

    private final JFileChooser LoadFile = new JFileChooser();
}
