package UI;

import MainFrame.ChessFrame.MainPanel;
import java.awt.Container;
import javax.swing.JFrame;

/**
 *
 * @author lisseth
 */
public class MainFrame extends JFrame {

    public MainFrame() {
        //clase que contiene la venta principar
        setTitle("Ajedrez"); //Nombre de la ventana
        setSize(615, 700);
        setResizable(false);

        contentPane.setLayout(null);
        contentPane.add(Satuspanel);

        MyChessBar = new Chess_MainMenuBar(this);

        setJMenuBar(MyChessBar);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public void start_Again() {
        Mainpanel.start_Again();

        contentPane.add(Mainpanel);

    }

    private final Chess_MainMenuBar MyChessBar;

    private final StatusPanel Satuspanel = new StatusPanel();

    private final MainPanel Mainpanel = new MainPanel(Satuspanel);
    private final Container contentPane = getContentPane();

}
