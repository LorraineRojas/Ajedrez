package UI;

import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author lisseth
 */
public class NewGameDialoge extends JDialog {
    //ventana emergente de juego nuevo

    public NewGameDialoge(final MainFrame ff) {
        super(ff, "Nuevo juego", true);

        setSize(300, 200);
        setLocation(100, 100);
        panel.setLayout(null);
        Container cp = getContentPane();

        button1 = new JButton("Iniciar");
        button2 = new JButton("Cancelar");
        message = new JLabel("  ");

        button1.setSize(100, 24);//tama�o botones inicio
        button2.setSize(100, 24);

        button1.setLocation(30, 100);//poscion botones
        button2.setLocation(150, 100);

        message.setEnabled(true);
        message.setText("Desea inicar el juego?");
        message.setLocation(80, 50);
        message.setSize(200, 20);
        mynewFrame = ff;

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                mynewFrame.start_Again();

                dispose();
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        panel.setLayout(null);

        panel.add(button1);
        panel.add(button2);
        panel.add(message);

        cp.add(panel);

    }

    private final JButton button1;
    private final JButton button2;
    private final JPanel panel = new JPanel();
    private final JLabel message;

    private MainFrame mynewFrame;

    @Override
    public void paintComponents(Graphics g) {
        super.paintComponents(g);

    }

}
