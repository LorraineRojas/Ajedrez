package UI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import UI.NewGameDialoge;

/**
 *
 * @author lisseth
 */
public class New_Item extends JMenu {//clase menu de juego nuevo

    public New_Item(MainFrame ff) {
        Ndial = new NewGameDialoge(ff);
        setText("Nuevo juego");

        OnePlayer.setEnabled(false);
        TwoPlayer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Ndial.setVisible(true);
            }
        });
        add(OnePlayer);
        add(TwoPlayer);
    }

    private final NewGameDialoge Ndial;
    private final JMenuItem OnePlayer = new JMenuItem("1 Jugador");
    private final JMenuItem TwoPlayer = new JMenuItem("2 Jugadores");

}
