package UI;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 *
 * @author lisseth
 */
public class StatusPanel extends JPanel { //clase para mostrar los turnos en la parte inferior

    public StatusPanel() {
        setSize(580, 30);
        setLocation(10, 610);
        setLayout(null);

        statusLabel.setSize(570, 25);
        statusLabel.setLocation(5, 5);
        statusLabel.setText("Comenzar nuevo juego ");
        statusLabel.setBackground(Color.lightGray);
        statusLabel.setFont(new Font("Aril", Font.BOLD, 11));
        statusLabel.setForeground(Color.black.brighter());
        statusLabel.setBorder(LabelBorder);
        add(statusLabel);

    }

    public void start_Again() {
        statusLabel.setText(" Comenzo el juego ");
    }

    public void changeStatus(Object str) {
        statusLabel.setText((String) str);
    }

    private final JLabel statusLabel = new JLabel();
    private final LineBorder LabelBorder = new LineBorder(Color.BLACK.brighter(), 2);
}
