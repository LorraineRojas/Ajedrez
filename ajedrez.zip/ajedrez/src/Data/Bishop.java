
package Data;

import java.awt.Image;
import java.awt.Point;
import java.io.IOException;


public class Bishop extends Ficha {

    
    public Bishop(String NameIcon, int startX, int startY) {

        super.setPieceImage(new PieceIcon(NameIcon));

        super.setX(startX);
        super.setY(startY);

    }

    
    public boolean Canmove(int x, int y) {

        int j = y;
        int i = x;

        if ((x - y) == (super.getX() - super.getY())) {

            return true;

        } 
        else if ((x + y) == (super.getX() + super.getY())) {
            return true;

        } else {
            return false;
        }

    }

    public boolean PieceInMYway(int x, int y, Point othersPostion) {

        int j = y;
        int i = x;

        if ((x - y) == (super.getX() - super.getY())) {
            if (x > super.getX() && y > super.getY()) {
                while ((j != super.getY() + 1) && (i != super.getX() + 1)) {
                    j--;
                    i--;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if (x < super.getX() && y < super.getY()) {
                while ((j != super.getY() - 1) && (i != super.getX() - 1)) {
                    j++;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }
            }
        } else if (((x + y)) == ((super.getX() + super.getY()))) {

            if ((super.getX() < i) && (super.getY() > j)) {

                while (((j != super.getY() - 1)) && ((i != super.getX() + 1))) {
                    j++;
                    i--;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {

                        return true;
                    }

                }

            } else if ((super.getX() > i) && (super.getY() < j)) {
                while ((j != super.getX() + 1) && (i != super.getX() - 1)) {
                    j--;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }
            }
        }

        return false;
    }

    public boolean checkKing(int x, int y, Point othersPostion) {

        int j = y;
        int i = x;

        if ((x - y) == (super.getX() - super.getY())) {
            if (x > super.getX() && y > super.getY()) {
                while ((j != super.getY()) && (i != super.getX())) {
                    j--;
                    i--;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if (x < super.getX() && y < super.getY()) {
                while ((j != super.getY()) && (i != super.getX())) {
                    j++;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }
            }
        } else if (((x + y)) == ((super.getX() + super.getY()))) {

            if ((super.getX() < i) && (super.getY() > j)) {

                while (((j != super.getY())) && ((i != super.getX()))) {
                    j++;
                    i--;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {

                        return true;
                    }

                }

            } else if ((super.getX() > i) && (super.getY() < j)) {
                while ((j != super.getX()) && (i != super.getX())) {
                    j--;
                    i++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }

                }
            }
        }

        return false;
    }

    

}

