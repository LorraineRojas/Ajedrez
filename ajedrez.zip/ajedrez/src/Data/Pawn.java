
package Data;

import java.awt.Color;
import java.awt.Image;
import java.awt.Point;
import java.io.IOException;

public class Pawn extends Ficha{
    
    
    private boolean movedbefore=false;
    
    private boolean myseen=false;
    public Pawn(String NameIcon, int startX, int startY) {

        super.setPieceImage(new PieceIcon(NameIcon));

        super.setX(startX);
        super.setY(startY);

    }
    
    @Override
    public void setPoint(Point newPoint) {
        
        super.setPoint(newPoint);
        movedbefore=true;
        myseen=false;
    }
    
    public boolean Canmove(int x, int y,String typeColor ) {
        
        if((typeColor.equals("black"))) {
            if((((y-1==super.getY())&&(x==(super.getX())))) /*&&!Check_Solider_Sees(x,y)*/) {
                
                return true;
                
            } else if((((y-2==super.getY())&&(x==(super.getX()))))&&!movedbefore ) {
                
                return true;
            } else if((y-1==super.getY()&&x+1==(super.getX())||(y-1==super.getY()&&x-1==(super.getX())))&&myseen ) {
                return true;
            }
            
            
            else  return false;
        }
        
        else if (typeColor=="white") {
            if(((y+1==super.getY())&&(x==(super.getX()))) /*&&!Check_Solider_Sees(x,y)*/) {
                return true;
            } else if((((y+2==super.getY())&&(x==(super.getX())))) &&!movedbefore) {
                return true;
            } else if((y+1==super.getY()&&x+1==(super.getX())||(y+1==super.getY()&&x-1==(super.getX())))&& myseen  ) {
                return true;
            }
            
            else
                return false;
        }
        return false;
        
        
        
    }
    public boolean PieceInMYway(int x, int y,Point othersPostion ,String typeColor ) {
        if(super.getY()-y==2||super.getY()-y==-2) {
            if((typeColor.equals("black"))) {
                
                if((((y-1==othersPostion.y)&&(x==(othersPostion.x))))&&!movedbefore ) {
                    return true;
                } else  return false;
            }
            
            else  if (typeColor.equals("white")) {
                
                if(((y+1==othersPostion.y)&&(x==(othersPostion.x)) &&!movedbefore)) {
                    
                    return true;
                    
                } else
                    return false;
            }
        }
        
        return false;
    }
   
    public void setMYseen(boolean newBoolean) {
        myseen=newBoolean;
    }
    public boolean returnMyseen() {
        return myseen;
    }
    public boolean setSeenbychecking(Point newP,String Color) {
        myseen=false;
        if((Color.equals("black"))) {
            if((newP.y-1==super.getY()&&newP.x+1==(super.getX())||(newP.y-1==super.getY()&&newP.x-1==(super.getX())))) {
                
                myseen=true;
                return true;
            } else return false;
        } else if(Color.equals("white")) {
            if((newP.y+1==super.getY()&&newP.x+1==(super.getX())||(newP.y+1==super.getY()&&newP.x-1==(super.getX())))) {
                myseen=true;
                
                return true;
            } else return false;
        }
        return false;
    }
    
    
}
