
package Data;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.applet.*;

import javax.imageio.ImageIO;

public class PieceIcon {
    private Toolkit kit=Toolkit.getDefaultToolkit();
    private Image image;
    
    
    public PieceIcon(String NameIcon) //throws IOException
    {
        
        image=kit.getImage(NameIcon);
    }
    
    public Image returnPieceIcon() {
        return image;
    }
    
    
    
}
