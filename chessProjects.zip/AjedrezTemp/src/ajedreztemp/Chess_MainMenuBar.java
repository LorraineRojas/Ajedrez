/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */

package ajedreztemp;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import ajedreztemp.File_Menu;

import ajedreztemp.MainFrame;
/**
 *
 * @author sami
 */
public class Chess_MainMenuBar extends JMenuBar
{
    
    /** Creates a new instance of Chess_MainMenuBar */
    public Chess_MainMenuBar(MainFrame ff)
    {
        Fmenu=new File_Menu(ff);
        add(Fmenu);

        
    }
    public String getIpAddress()
    {
        return Fmenu.getIPaddress();
    }
    public String getPortnumber()
    {
        return Fmenu.getportNumber();
    }
    
    private final File_Menu Fmenu;
    
    /*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */
}
