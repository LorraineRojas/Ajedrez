/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */

package ajedreztemp;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JMenu;
import ajedreztemp.New_Item;

import ajedreztemp.MainFrame;


/**
 *
 * @author sami
 */
public class File_Menu extends JMenu
{
    
    /** Creates a new instance of File_Menu */
    public File_Menu(MainFrame ff)
    {
        NItem=new New_Item(ff);
        setText("File");
        
        
        
        add(NItem);
        addSeparator();
        
        
    }
    public String getIPaddress()
    {
        return NItem.getIpAddress();
    }
    public String getportNumber()
    {
        return NItem.getportNumber();
    }
    
    
    private final New_Item NItem;
    
    
}/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */
