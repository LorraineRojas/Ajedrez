/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */

package ajedreztemp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.border.BevelBorder;

import javax.swing.JScrollPane;

/**
 *
 * @author sami
 */
public class MainFrame extends JFrame {
    
    
    
    public MainFrame() {
        setTitle("Chess Game");
        setSize(800,700);
        setResizable(false);
        
        contentPane.setLayout(null);
 
        
        MyChessBar=new Chess_MainMenuBar(this);
        
        setJMenuBar(MyChessBar);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    public void start_Again() {
        Mainpanel.start_Again();
        
        
        
        
        contentPane.add(Mainpanel);
        
        
        
        
        
        
    }
    
    
    
    
    private final Chess_MainMenuBar  MyChessBar ;
    
    
    private final MainPanel Mainpanel=new MainPanel();
    
    private  Container contentPane=getContentPane();
    
}

/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */

