package ajedrez;

import java.awt.Image;
import java.awt.Point;
import java.io.IOException;

/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */
public class Rook extends Ficha {

    public Rook(String NameIcon, int startX, int startY) {

        PieceIcon PieceIcon = new PieceIcon(NameIcon);

        super.setX(startX);
        super.setY(startY);

    }

    public boolean Canmove(int x, int y) {
        if (((y == super.getY()) && (x > (super.getX()) || (x < (super.getX()))))) {
            return true;
        } else if ((((y > super.getY()) || (y < super.getY())) && (x == (super.getX())))) {
            return true;
        } else {

            return false;
        }

    }

    public boolean PieceInMYway(int x, int y, Point othersPostion) {
        int j = y;
        int i = x;
        if (((y == super.getY()) && (x > (super.getX()) || (x < (super.getX()))))) {

            if ((super.getX() < i)) {
                while ((i != super.getX() + 1)) {
                    i--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i)))//there Same Color piece
                    {
                        return true;
                    }
                }
            } else if ((super.getX() > i)) {
                while ((i != super.getX() - 1)) {
                    i++;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            }
        } else if ((((y > super.getY()) || (y < super.getY())) && (x == (super.getX())))) {
            if ((super.getY() < j)) {
                while ((j != super.getY() + 1)) {
                    j--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if ((super.getY() > j)) {
                while ((j != super.getY() - 1)) {
                    j++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }

            }
        }
        return false;

    }

    public boolean checkKing(int x, int y, Point othersPostion) {
        int j = y;
        int i = x;
        if (((y == super.getY()) && (x > (super.getX()) || (x < (super.getX()))))) {

            if ((super.getX() < i)) {
                while ((i != super.getX())) {
                    i--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i)))//there Same Color piece
                    {
                        return true;
                    }
                }
            } else if ((super.getX() > i)) {
                while ((i != super.getX())) {
                    i++;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            }
        } else if ((((y > super.getY()) || (y < super.getY())) && (x == (super.getX())))) {
            if ((super.getY() < j)) {
                while ((j != super.getY())) {
                    j--;
                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }
            } else if ((super.getY() > j)) {
                while ((j != super.getY())) {
                    j++;

                    if (((othersPostion.y) == j) && ((othersPostion.x == i))) {
                        return true;
                    }
                }

            }
        }
        return false;

    }

    public Point GeneratePossible_Moves() {
        return new Point();
    }

}/*
 *   *       Please Visit us at www.codemiles.com     *
 *  This Program was Developed by www.codemiles.com forums Team
 *  *           Please Don't Remove This Comment       *
 */
